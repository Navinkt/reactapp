import "./App.css";
import { Footer } from "./components/Footer/Footer";
import { Navbar } from "./components/Navbar/Navbar";
import { Products } from "./components/Products/Products";
import { Section } from "./components/section/Section";

function App() {
  return (
    <div className="main">
      <Navbar />
      <Section />
      <Products />
      <Footer/>
    </div>
  );
}

export default App;
