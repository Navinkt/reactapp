import styles from "./Section.module.css";
import classNames from "classnames";
import award from "../../assets/asserts/1.png";
import prize from "../../assets/asserts/2.png";

export const Section = () => {
  return (
    <div className={classNames(styles.sectionContainer)}>
      
      <img className={classNames(styles.awardLogo)} src={award} alt="award" />

      <div className={classNames(styles.mainSection)}>
        <p className={classNames(styles.heading)}>
          C.R.I. PUMPS WINS THE NATIONAL ENERGY CONSERVATION AWARD 2018 for the
          4th time.
        </p>
        <ul >
          <li className={classNames(styles.list)}>
            C.R.I.s energye lclent pro uctsarewe recogmz various projects across
            the globe to save ene vanous Government Institutions, as trustwo
            ucts or
          </li>
          <li className={classNames(styles.list)}>
            s e g con u or e coun or e pro nergy ency ces e old inefficient
            pumps with 5 Star rated energy efficient smart pumps with IOT
            enabled control panel.
          </li>
          <img className={classNames(styles.prize)} src={prize} alt="prize" />
        </ul>
        <p className={classNames(styles.about)}>Government of India has awarded the •National Energy Conservation Award 2018•. Mr. G. Selvaraj, Joint Managing Director
of C.R.I. Group received the award from Smt. Sumitra Mahajan, speaker of Lok Sabha 8 shri, Raj Kumar Singh, Honorable
Minister of State.</p>
      </div>
    </div>
  );
};
