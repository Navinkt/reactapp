import styles from "./Footer.module.css";
import classNames from "classnames";

export const Footer = () => {
  const footerList = [
    [<i class="fas fa-phone-alt"></i>,"Toll free 1800 200 1234" ],
    [<i class="fab fa-facebook"></i>,"www.facebook.com/cripumps"],
    [<i class="fas fa-globe"></i>,"www.crigroups.com"],
  ];
  return (
  <div className={classNames(styles.footerContainer)}>
    {footerList.map((item) => {
        return (
            <p>{item}</p>
        )
    })}
  </div>
  );
};
