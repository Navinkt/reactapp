import styles from "./Navbar.module.css"
import classNames from "classnames";
import brandlogo from "../../assets/asserts/logo.png"

export const Navbar = () => {
  return (
    <div className={classNames(styles.navContainer)}>
        <img className={classNames(styles.navlogo)} src={brandlogo} alt="Brand logo" />
    </div>
  )
}
