import styles from "./Products.module.css";
import classNames from "classnames";
import product from "../../assets/asserts/3.png";

const VerticalLine = () => {
    return (
        <div className={classNames(styles.vertical)}></div>
    )
}

export const Products = () => {

const productList = ["CHEMICALS & PROCESS",<VerticalLine/>, "POWER",<VerticalLine/>, "WATER & WASTE WATER",<VerticalLine/>, "OILS & GAS",<VerticalLine/>, "PHARMA",<VerticalLine/>, "SUGARS & DISTILLERIES",<VerticalLine/>, "PAPER & PULP",<VerticalLine/>, "MARINE & DEFENCE",<VerticalLine/>, "METAL & MINING",<VerticalLine/>, "FOOD & BEVERAGE",<VerticalLine/>, "PETROCHEMICAL & REFINERIES",<VerticalLine/>, "SOLAR",<VerticalLine/>, "BUILDING",<VerticalLine/>, "HVAC",<VerticalLine/>, "FIRE FIGHTING",<VerticalLine/>, "AGRICULTURE & RESIDENTIAL"]


  return (
    <div className={classNames(styles.productContainer)}>
        <p className={classNames(styles.title)}>INSTALLED OVER 10 LAKHS STAR RATED PUMPSETS ACROSS THE COUNTRY RESULTING IN A CUMULATIVE SAVING OF MORE THAN 9,000 MILLION UNITS OF POWER FOR THE NATION.</p>
        <img className={classNames(styles.products)} src={product} alt="" />
        <p className={classNames(styles.productName)}>valves - Pumps - Pipes - IoT Drives & controllers - Wires & cables - solar Systems-Motors</p>
        <div className={classNames(styles.line)}></div>
        <p className={classNames(styles.productName)}>C.R.I. FLUID SYSTEMS PRODUCTS CATER TO DIVERSE SEGMENTS</p>
        <div className={classNames(styles.industriesList)}>
            {productList.map((item) => {
                return (
                    <p className={classNames(styles.industrieItemName)}>{item}</p>
                )
            })}
        </div>
    </div>
  )
}
